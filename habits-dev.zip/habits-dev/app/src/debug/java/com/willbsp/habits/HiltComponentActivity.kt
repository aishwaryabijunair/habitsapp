package com.willbsp.habits

import androidx.activity.ComponentActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HiltComponentActivity : ComponentActivity()